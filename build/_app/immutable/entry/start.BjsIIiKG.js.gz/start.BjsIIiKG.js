import{l as o,s as r}from"../chunks/B1TB5Ay-.js";export{o as load_css,r as start};
